package server;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import java.util.*;
import java.net.MalformedURLException;
import java.net.URL;
public class CugloginTest {
  private WebDriver driver;
  private Map<String, Object> vars;
  JavascriptExecutor js;
  public String waitForWindow(int timeout) {
    try {
      Thread.sleep(timeout);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    Set<String> whNow = driver.getWindowHandles();
    Set<String> whThen = (Set<String>) vars.get("window_handles");
    if (whNow.size() > whThen.size()) {
      whNow.removeAll(whThen);
    }
    return whNow.iterator().next();
  }
  public void cuglogin() {
	  driver = new ChromeDriver();
	  js = (JavascriptExecutor) driver;
	  vars = new HashMap<String, Object>();
    // Step # | name | target | value | comment
    // 1 | open | / |  | 
    driver.get("https://www.cug.edu.cn/");
    // 2 | setWindowSize | 1536x806 |  | 
    driver.manage().window().setSize(new Dimension(1536, 806));
    // 3 | click | linkText=信息门户 |  | 
    driver.findElement(By.linkText("信息门户")).click();
    // 4 | click | linkText=QQ登录 |  | 
    driver.findElement(By.linkText("QQ登录")).click();
    // 5 | selectFrame | index=0 |  | 
    driver.switchTo().frame(0);
    // 6 | click | id=switcher_plogin |  | 
    driver.findElement(By.id("switcher_plogin")).click();
    // 7 | click | id=u |  | 
    driver.findElement(By.id("u")).click();
    // 8 | type | id=u | 984268528 | 
    driver.findElement(By.id("u")).sendKeys("984268528");
    // 9 | click | id=p |  | 
    driver.findElement(By.id("p")).click();
    // 10 | type | id=p | fzxp20180520 | 
    driver.findElement(By.id("p")).sendKeys("fzxp20180520");
    // 11 | click | id=login_button |  | 
    driver.findElement(By.id("login_button")).click();
    // 12 | selectFrame | relative=parent |  | 
    driver.switchTo().defaultContent();
    // 13 | click | css=.user-number-row |  | 
    driver.findElement(By.cssSelector(".user-number-row")).click();
    // 14 | click | css=.sys-item:nth-child(3) .mCS_img_loaded |  | 
    vars.put("window_handles", driver.getWindowHandles());
    // 15 | storeWindowHandle | root |  | 
    driver.findElement(By.cssSelector(".sys-item:nth-child(3) .mCS_img_loaded")).click();
    // 16 | selectWindow | handle=${win5125} |  | 
    vars.put("win5125", waitForWindow(2000));
    // 17 | close |  |  | 
    vars.put("root", driver.getWindowHandle());
    // 18 | selectWindow | handle=${root} |  | 
    driver.switchTo().window(vars.get("win5125").toString());
    // 19 | close |  |  | 
    driver.close();
    // 20 | selectWindow | handle=${undefined} |  | 
    driver.switchTo().window(vars.get("root").toString());
    driver.close();
    driver.switchTo().window(vars.get("undefined").toString());
    
    
    driver.quit();
  }
}
