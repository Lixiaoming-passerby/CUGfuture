package server;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

public class SearchNews extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/json;charset=UTF-8");
		Connection cn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String keyword = request.getParameter("keyword");
		System.out.println(keyword);
		ArrayList myNews =new ArrayList();
		Gson gson = new Gson();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			cn = DriverManager.getConnection("jdbc:mysql://8.140.103.153:3306/cug_future?characterEncoding=UTF-8","root","********");
			System.out.println(keyword);
			ps = cn.prepareStatement("select * from NEWS where TITLE like ?");
			ps.setString(1, "%"+keyword+"%");
			System.out.println(ps);
			rs = ps.executeQuery();
			while(rs.next()) {
				System.out.println(1);
				Integer num=rs.getInt("NUM");
				String title=rs.getString("TITLE");
			    String cont_index=rs.getString("CONT_INDEX");
			    Integer viewVol=rs.getInt("VIEW_VOL");
			    String newsTime= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(rs.getTimestamp("NEWS_TIME"));
			    String img=rs.getString("IMG_INDEX");
			    
			    String content = "";
				File file = new File(cont_index);
				InputStreamReader isr = new InputStreamReader(new FileInputStream(file), "UTF-8");
			    BufferedReader reader = null;
			    String tempString = null;			    
			    try {
			    	reader = new BufferedReader(isr);
			        while ((tempString = reader.readLine()) != null) {
			            content+=tempString;
			            content+='\n';
			        }
			        reader.close();
			    } catch (FileNotFoundException e) {
			        // TODO Auto-generated catch block
			        e.printStackTrace();
			    } catch (IOException e) {
			        // TODO Auto-generated catch block
			        e.printStackTrace();
			    }finally{
			        if(reader != null){
			            try {
			                reader.close();
			            } catch (IOException e) {
			                // TODO Auto-generated catch block
			                e.printStackTrace();
			            }
			        }
			    }
			    
			    
				News news=new News();
				news.setTitle(title);
				news.setContent(content);
				news.setNum(num);
				news.setNewsTime(newsTime);
				news.setViewVo(viewVol);
				String[] imgArray = img.split(";");
		        for (int k = 0; k < imgArray.length; k++) {
		        	news.setImg(imgArray[k]);
		        }
				news.setImg(img);
				myNews.add(news);
			}
			Collections.reverse(myNews);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null)
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if(ps!=null)
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if(cn!=null)
				cn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		String json = gson.toJson(myNews);
		response.getWriter().write(json);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}
}
