package server;

public class Classroom {
	private String type;
	private String seatnum;
	private String used;
	
	
	public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    public String getSeatnum() {
        return seatnum;
    }

    public void setSeatnum(String seatnum) {
        this.seatnum = seatnum;
    }
    public String getUsed() {
        return used;
    }

    public void setUsed(String used) {
        this.used = used;
    }

}
