package server;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

public class SendRelease extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/json;charset=UTF-8");
		Connection cn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String username = request.getParameter("username");
		Gson gson = new Gson();
		ArrayList myRelease =new ArrayList();
		String str = "";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			cn = DriverManager.getConnection("jdbc:mysql://8.140.103.153:3306/cug_future?characterEncoding=UTF-8","root","********");
			ps = cn.prepareStatement("select RELEINDEX from RELEASED where NAME ='"+username+"'");
			rs = ps.executeQuery();
			if(rs.next()) {
				str=rs.getString(1); 
			}else {
				System.out.println("�������");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null)
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if(ps!=null)
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if(cn!=null)
				cn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		String[] indexArray = {};
		if(!str.isEmpty())indexArray =str.split(";");
		int i = indexArray.length-1;
		System.out.println(i);
		while(i>=0) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				cn = DriverManager.getConnection("jdbc:mysql://8.140.103.153:3306/cug_future","root","********");
				ps = cn.prepareStatement("select * from COMMUNITY where NUM="+indexArray[i]);
				rs = ps.executeQuery();
				if(rs.next()) {
					String name=rs.getString("NAME");
					String head=rs.getString("HEAD");
				    String content=rs.getString("CONTENT");
				    Integer likeVol=rs.getInt("LIKE_VOL");
				    String tcTime= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(rs.getTimestamp("TC_TIME"));
				    String img=rs.getString("IMG_INDEX");
				    String likelist = rs.getString("LIKELIST");
				    String storelist = rs.getString("STORELIST");
				    String commentlist = rs.getString("COMMENT");
				    
				    				    				    
					TUCAO tucao = new TUCAO();
					tucao.setNum(i);
					tucao.setName(name);
					tucao.setHead(head);
					tucao.setContent(content);
					tucao.setTucaoTime(tcTime);
					tucao.setlikeVol(likeVol);
					String[] imgArray ={};
					if(!img.isEmpty())imgArray = img.split(";");
			        for (int k = 0; k < imgArray.length; k++) {
			        	tucao.setImg(imgArray[k]);
			        }
			        String[] nameArray ={};
			        if(!likelist.isEmpty())nameArray = likelist.split(";");
			        for (int k = 0; k < nameArray.length; k++) {
			        	tucao.setLikeList(nameArray[k]);
			        }
			        String[] commentArray = {};
			        if(!commentlist.isEmpty())   //������ʶ
			        {
			        	commentArray= commentlist.split("/#/");
			        }
			        for (int k = 0; k < commentArray.length; k++) {
			        	int index = commentArray[k].indexOf(':');
			        	String name1 =commentArray[k].substring(0, index);
			        	String text = commentArray[k].substring(index+1);
			        	Comment comment = new Comment();
			        	comment.setName(name1);
			        	comment.setText(text);
			        	tucao.setCommentList(comment);
			        }
			        if(Arrays.asList(nameArray).contains(username))
			        {
			        	tucao.setLikeState(1);
			        }
			        String[] storeArray = storelist.split(";");
			        if(Arrays.asList(storeArray).contains(username))
			        {
			        	tucao.setStState(1);
			        }
			        myRelease.add(tucao);
				}else {
					System.out.println("�������");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}finally {
				try {
					if(rs!=null)
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				try {
					if(ps!=null)
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				try {
					if(cn!=null)
					cn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			i--;
		}
		String json = gson.toJson(myRelease);
		response.getWriter().write(json);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}
}
